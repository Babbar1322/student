


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="text-center pt-2">
                   Welcome to Admin Dashboard !
               </div>

                <div class="card-body">
                    <?php if(Session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session('status')); ?>

                        </div>
                    <?php endif; ?>
                   

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\student\resources\views/admin_dashboard.blade.php ENDPATH**/ ?>