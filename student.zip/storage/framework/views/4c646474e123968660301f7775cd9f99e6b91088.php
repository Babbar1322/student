
  
<?php $__env->startSection('content'); ?>
<main class="login-form">
  <div class="cotainer">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header">Register</div>
                  <div class="card-body">
  
                      <form action="<?php echo e(route('register.post')); ?>" method="POST" enctype="multipart/form-data">
                          <?php echo csrf_field(); ?>
                          <div class="form-group row">
                              <label for="name" class="col-md-4 col-form-label text-md-right">Name</label>
                              <div class="col-md-6">
                                  <input type="text" id="name" class="form-control" name="name" required autofocus>
                                  <?php if($errors->has('name')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          
                          <div class="form-group row">
                            <label for="email_address" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>
                            <div class="col-md-6">
                                <input type="text" id="email_address" class="form-control" name="email" required autofocus>
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                          <div class="form-group row">
                              <label for="age" class="col-md-4 col-form-label text-md-right">Age</label>
                              <div class="col-md-6">
                                  <input type="text" id="age" class="form-control" name="age" required autofocus>
                                  <?php if($errors->has('age')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('age')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="form-group row">
                              <label for="dob" class="col-md-4 col-form-label text-md-right">DOB</label>
                              <div class="col-md-6">
                                  <input type="text" id="dob" class="form-control" name="dob" required autofocus>
                                  <?php if($errors->has('dob')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('dob')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="form-group row">
                              <label for="address" class="col-md-4 col-form-label text-md-right">Address</label>
                              <div class="col-md-6">
                                  <input type="text" id="address" class="form-control" name="address" required autofocus>
                                  <?php if($errors->has('address')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="form-group row">
                              <label for="role" class="col-md-4 col-form-label text-md-right">Role</label>
                              <div class="col-md-6">
                                  <select name="role" id="role" class="form-control">
                                      <option value="admin">Admin</option>
                                      <option value="manager">manager</option>
                                  </select>
                                  <?php if($errors->has('role')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('role')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="form-group row">
                              <label for="image" class="col-md-4 col-form-label text-md-right">Profile Picture</label>
                              <div class="col-md-6">
                                  <input type="file" id="image" class="form-control" name="image" required autofocus>
                                  <?php if($errors->has('image')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
  
  
                          <div class="form-group row">
                              <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                              <div class="col-md-6">
                                  <input type="password" id="password" class="form-control" name="password" required>
                                  <?php if($errors->has('password')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>

  
                          <div class="col-md-6 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  Register
                              </button>
                          </div>
                      </form>
                        
                  </div>
              </div>
          </div>
      </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\student\resources\views/register.blade.php ENDPATH**/ ?>